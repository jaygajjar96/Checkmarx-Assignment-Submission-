#!/usr/bin/env python3
"""
pypi_scraper.py

Usage:
    python pypi_scraper.py <package_name> [--format wheel|sdist|both] [--json <file.json>] [--out <dir>]
    python pypi_scraper.py <package_name> --no-download (metadata + risk signals only, no download)

Author: Jay Gajjar
"""

import argparse
import ast
import hashlib
import json
import os
import re
import sys
import tarfile
import zipfile
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

# TOML parsing for pyproject.toml. tomllib is stdlib on Python 3.11+;
# on 3.8-3.10 (common on Windows) it isn't, so fall back to the `tomli`
# backport if it's installed, and degrade gracefully if neither exists.
try:
    import tomllib as _toml            # Python 3.11+
except ModuleNotFoundError:            # pragma: no cover
    try:
        import tomli as _toml          # pip install tomli
    except ModuleNotFoundError:
        _toml = None

# ---------------------------------------------------------------------------
# Config / constants
# ---------------------------------------------------------------------------

PYPI_JSON_API = "https://pypi.org/pypi/{package}/json"
ALLOWED_HOST_SUFFIXES = ("pypi.org", "files.pythonhosted.org")
REQUEST_TIMEOUT = 15  # seconds - don't let a hung connection stall the tool
MAX_DOWNLOAD_BYTES = 200 * 1024 * 1024  # 200 MB cap, guards against a malicious or compromised index serving a huge/zip-bomb-style artifact
CHUNK_SIZE = 64 * 1024

# PEP 503 / PEP 508 style project name: letters, digits, ., -, _
PACKAGE_NAME_RE = re.compile(r"^[A-Za-z0-9]([A-Za-z0-9._-]*[A-Za-z0-9])?$")

class ScraperError(Exception):
    """Base class for anything that should abort the run with a clean message."""

class UntrustedSourceError(ScraperError):
    """Raised when a URL points somewhere other than the official PyPI CDN."""

class IntegrityError(ScraperError):
    """Raised when a downloaded file doesn't match the hash PyPI advertised."""


@dataclass
class Artifact:
    """One downloaded release file (a single .whl or .tar.gz), with its
    own integrity check and dependency list. A package release can ship
    several of these, so we track them individually."""
    filename: str
    url: str
    packagetype: str          # "bdist_wheel" or "sdist"
    sha256_expected: str = ""
    sha256_actual: str = ""
    integrity_verified: bool = False
    # each dependency is {"requirement": "certifi>=x", "source": "setup.py"}
    dependencies: list = field(default_factory=list)
    files_found: list = field(default_factory=list)    # source files we parsed
    files_missing: list = field(default_factory=list)   # expected files not present

    def to_dict(self):
        return self.__dict__


@dataclass
class PackageReport:
    name: str
    requested_format: str
    resolved_version: str = ""
    metadata: dict = field(default_factory=dict)       # info useful for triage
    risk_signals: list = field(default_factory=list)    # heuristic flags, not a verdict
    artifacts: list = field(default_factory=list)       # list[Artifact]
    dependencies: list = field(default_factory=list)    # union, source-tagged
    warnings: list = field(default_factory=list)

    def to_dict(self):
        return {
            "name": self.name,
            "requested_format": self.requested_format,
            "resolved_version": self.resolved_version,
            "metadata": self.metadata,
            "risk_signals": self.risk_signals,
            "artifacts": [a.to_dict() for a in self.artifacts],
            "dependencies": self.dependencies,
            "warnings": self.warnings,
        }


# ---------------------------------------------------------------------------
# Step 1: Name Validation + Version Lookup
# ---------------------------------------------------------------------------

def validate_package_name(name: str) -> str:
    """
    Reject anything that isn't a valid or believable PyPI project name before it
    ever touches a URL or a filesystem path. This is the cheapest possible
    defense against argument injection / path traversal via a crafted
    package name (e.g. "../../etc/passwd" or "requests; rm -rf ~").
    """
    name = name.strip()
    if not name or len(name) > 214:  # PyPI's own length limit
        raise ScraperError(f"'{name}' is not a valid package name.")
    if not PACKAGE_NAME_RE.match(name):
        raise ScraperError(
            f"'{name}' contains characters that aren't valid in a PyPI "
            "project name - refusing to continue."
        )
    return name


def assert_trusted_host(url: str) -> None:
    """Make sure we only ever talk to pypi.org or its file CDN, over HTTPS."""
    if not url.startswith("https://"):
        raise UntrustedSourceError(f"Refusing non-HTTPS URL: {url}")
    host = url.split("/")[2].lower()
    if not any(host == s or host.endswith("." + s) for s in ALLOWED_HOST_SUFFIXES):
        raise UntrustedSourceError(f"Refusing to fetch from untrusted host: {host}")


def fetch_json(url: str) -> dict:
    assert_trusted_host(url)
    req = Request(url, headers={"User-Agent": "pypi-dependency-scraper/1.0"})
    try:
        with urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except HTTPError as e:
        if e.code == 404:
            raise ScraperError(f"Package not found on PyPI (HTTP 404).")
        raise ScraperError(f"PyPI returned HTTP {e.code} for {url}")
    except URLError as e:
        raise ScraperError(f"Network error reaching PyPI: {e.reason}")


def get_package_metadata(package: str) -> dict:
    """Pull the full project JSON - this gives us the latest version plus
    every release file (wheel/sdist) with its published hashes, all in
    one call."""
    return fetch_json(PYPI_JSON_API.format(package=package))


# ---------------------------------------------------------------------------
# Step 2: Pick + Download the release artifact
# ---------------------------------------------------------------------------

def pick_release_files(urls: list, preferred_format: str) -> list:
    """
    urls is the "urls" array from the PyPI JSON API for a given release.
    preferred_format is "wheel", "sdist", or "both".

    Returns a LIST of file_info dicts to download:
      - "wheel" -> one wheel
      - "sdist" -> one sdist (.tar.gz)
      - "both"  -> one wheel AND one sdist (whichever are published)

    Note we take only the *first* wheel even when many are published.
    Their declared dependencies are identical, so downloading them all would
    just waste bandwidth.
    """
    wheels = [u for u in urls if u.get("packagetype") == "bdist_wheel"]
    sdists = [u for u in urls if u.get("packagetype") == "sdist"]

    chosen = []
    if preferred_format == "wheel":
        chosen = wheels[:1]
    elif preferred_format == "sdist":
        chosen = sdists[:1]
    elif preferred_format == "both":
        chosen = wheels[:1] + sdists[:1]

    if not chosen:
        raise ScraperError(
            f"No '{preferred_format}' release artifact is published for this version."
        )
    return chosen


def download_artifact(file_info: dict, dest_dir: Path) -> Path:
    url = file_info["url"]
    assert_trusted_host(url)

    expected_size = file_info.get("size", 0)
    if expected_size and expected_size > MAX_DOWNLOAD_BYTES:
        raise ScraperError(
            f"Advertised file size ({expected_size} bytes) exceeds the "
            f"{MAX_DOWNLOAD_BYTES} byte safety cap - not downloading."
        )

    filename = file_info["filename"]
    # belt-and-braces: filename comes from PyPI's own API, but we still strip any path separators before joining it to a local directory
    filename = os.path.basename(filename)
    dest_path = dest_dir / filename

    req = Request(url, headers={"User-Agent": "pypi-dependency-scraper/1.0"})
    hasher = hashlib.sha256()
    total = 0

    with urlopen(req, timeout=REQUEST_TIMEOUT) as resp, open(dest_path, "wb") as f:
        while True:
            chunk = resp.read(CHUNK_SIZE)
            if not chunk:
                break
            total += len(chunk)
            if total > MAX_DOWNLOAD_BYTES:
                f.close()
                dest_path.unlink(missing_ok=True)
                raise ScraperError(
                    "Download exceeded the safety size cap mid-stream - aborted "
                    "and deleted the partial file."
                )
            hasher.update(chunk)
            f.write(chunk)

    actual_hash = hasher.hexdigest()
    expected_hash = file_info.get("digests", {}).get("sha256", "")

    if not expected_hash:
        dest_path.unlink(missing_ok=True)
        raise IntegrityError("PyPI did not publish a sha256 digest to verify against.")

    if actual_hash != expected_hash:
        dest_path.unlink(missing_ok=True) 
        raise IntegrityError(
            f"Hash mismatch for {filename}!\n"
            f"  expected: {expected_hash}\n"
            f"  got:      {actual_hash}\n"
            "This could mean a corrupted download or a compromised mirror. "
            "The file has been deleted."
        )

    return dest_path, actual_hash, expected_hash


# ---------------------------------------------------------------------------
# Step 3: Safe extraction (zip-slip / tar-slip protection)
# ---------------------------------------------------------------------------

def _is_within_directory(directory: Path, target: Path) -> bool:
    try:
        directory = directory.resolve()
        target = target.resolve()
    except OSError:
        return False
    return str(target).startswith(str(directory) + os.sep) or target == directory


def safe_extract_tar(tar: tarfile.TarFile, path: Path) -> None:
    """
    Refuses to extract any member whose resolved path would land outside
    `path`, and refuses symlinks/hardlinks entirely. This is the classic
    """
    for member in tar.getmembers():
        member_path = path / member.name
        if not _is_within_directory(path, member_path):
            raise ScraperError(
                f"Refusing to extract '{member.name}': path traversal attempt detected."
            )
        if member.issym() or member.islnk():
            raise ScraperError(
                f"Refusing to extract '{member.name}': symlink/hardlink entries are not allowed."
            )
    tar.extractall(path)  


def safe_extract_zip(zf: zipfile.ZipFile, path: Path) -> None:
    for name in zf.namelist():
        member_path = path / name
        if not _is_within_directory(path, member_path):
            raise ScraperError(
                f"Refusing to extract '{name}': path traversal attempt detected."
            )
    zf.extractall(path)


# ---------------------------------------------------------------------------
# Step 4: Dependency extraction (static only - nothing here ever executes
# code from the downloaded package)
# ---------------------------------------------------------------------------

def parse_wheel_metadata(whl_path: Path) -> dict:
    """A wheel is just a zip.
    Returns a dict: {"dependencies": [{"requirement","source"}...],
                     "files_found": [...], "files_missing": [...]}."""
    entries = []
    found, missing = [], []
    with zipfile.ZipFile(whl_path) as zf:
        metadata_name = next(
            (n for n in zf.namelist() if n.endswith(".dist-info/METADATA")), None
        )
        if not metadata_name:
            missing.append("*.dist-info/METADATA")
            return {"dependencies": entries, "files_found": found, "files_missing": missing}
        found.append("METADATA (wheel)")
        content = zf.read(metadata_name).decode("utf-8", errors="replace")
        for line in content.splitlines():
            if line.startswith("Requires-Dist:"):
                entries.append({
                    "requirement": line.split(":", 1)[1].strip(),
                    "source": "METADATA (wheel)",
                })
    return {"dependencies": entries, "files_found": found, "files_missing": missing}


def parse_setup_py_statically(setup_py_text: str) -> list:
    """
    Parses setup.py with `ast` - builds a syntax tree, never calls
    exec()/import on the file.
    """
    deps = []
    try:
        tree = ast.parse(setup_py_text)
    except SyntaxError:
        return deps

    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            for kw in node.keywords:
                if kw.arg == "install_requires":
                    deps.extend(_literal_strings(kw.value))
    return deps


def _literal_strings(node) -> list:
    """Pull plain string literals out of a list/tuple AST node, ignoring
    anything computed (function calls, variables, etc.)"""
    out = []
    if isinstance(node, (ast.List, ast.Tuple)):
        for el in node.elts:
            if isinstance(el, ast.Constant) and isinstance(el.value, str):
                out.append(el.value)
    return out


def parse_pyproject_toml(text: str) -> list:
    """
    Parse dependencies out of pyproject.toml - the modern replacement for setup.py.
    """
    if _toml is None:
        return []
    try:
        data = _toml.loads(text)
    except Exception:
        return []  

    deps = []

    # --- PEP 621: the standard, tool-agnostic location ---
    project = data.get("project", {})
    for dep in project.get("dependencies", []):
        if isinstance(dep, str):
            deps.append(dep)
    for extra, extra_deps in project.get("optional-dependencies", {}).items():
        for dep in extra_deps:
            if isinstance(dep, str):
                deps.append(f'{dep} ; extra == "{extra}"')

    # --- Poetry: still very common in the wild ---
    poetry = data.get("tool", {}).get("poetry", {})
    for name, spec in poetry.get("dependencies", {}).items():
        if name.lower() == "python":
            continue  # this is the interpreter constraint, not a real dependency
        if isinstance(spec, str):
            deps.append(f"{name} {spec}".strip())
        elif isinstance(spec, dict) and "version" in spec:
            deps.append(f"{name} {spec['version']}".strip())
        else:
            deps.append(name)  # git/path/url dep - just record the name

    return deps


def parse_requirements_txt(text: str) -> list:
    deps = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("-"):
            continue
        deps.append(line)
    return deps


def extract_sdist_dependencies(sdist_path: Path, work_dir: Path) -> dict:
    """
    Extract declared dependencies from an sdist, tagging each with the
    file it came from, and reporting which of the expected source files
    were present vs. missing.

    Returns: {"dependencies": [{"requirement","source"}...],
              "files_found": [...], "files_missing": [...]}
    """
    entries = []
    found, missing = [], []
    extract_to = work_dir / "extracted"
    extract_to.mkdir(exist_ok=True)

    # An sdist is usually a .tar.gz, but some (often older) packages ship a .zip instead. 

    if zipfile.is_zipfile(sdist_path):
        with zipfile.ZipFile(sdist_path) as zf:
            safe_extract_zip(zf, extract_to)
    elif tarfile.is_tarfile(sdist_path):
        with tarfile.open(sdist_path, "r:*") as tar:
            safe_extract_tar(tar, extract_to)
    else:
        raise ScraperError(
            f"'{sdist_path.name}' is neither a valid tar nor zip archive - "
            "cannot extract dependencies from it."
        )

    # sdists extract into a single top-level "<name>-<version>/" folder
    subdirs = [p for p in extract_to.iterdir() if p.is_dir()]
    root = subdirs[0] if subdirs else extract_to

    setup_py = root / "setup.py"
    setup_cfg = root / "setup.cfg"
    pyproject = root / "pyproject.toml"
    pkg_info = root / "PKG-INFO"
    req_txt = root / "requirements.txt"

    def _mark(path: Path, label: str, present: bool):
        (found if present else missing).append(label)

    # 1) pyproject.toml first - modern standard, many packages ship no setup.py
    if pyproject.exists():
        _mark(pyproject, "pyproject.toml", True)
        for r in parse_pyproject_toml(pyproject.read_text(errors="replace")):
            entries.append({"requirement": r, "source": "pyproject.toml"})
    else:
        _mark(pyproject, "pyproject.toml", False)

    # 2) setup.py (install_requires), parsed via ast, never executed
    if setup_py.exists():
        _mark(setup_py, "setup.py", True)
        for r in parse_setup_py_statically(setup_py.read_text(errors="replace")):
            entries.append({"requirement": r, "source": "setup.py (install_requires)"})
    else:
        _mark(setup_py, "setup.py", False)

    # 3) setup.cfg [options] install_requires
    if setup_cfg.exists():
        _mark(setup_cfg, "setup.cfg", True)
        in_block = False
        for line in setup_cfg.read_text(errors="replace").splitlines():
            if re.match(r"^\s*install_requires\s*=", line):
                in_block = True
                continue
            if in_block:
                if line.startswith((" ", "\t")) and line.strip():
                    entries.append({"requirement": line.strip(),
                                    "source": "setup.cfg (install_requires)"})
                elif line.strip() == "" or not line.startswith((" ", "\t")):
                    in_block = False
    else:
        _mark(setup_cfg, "setup.cfg", False)

    # 4) requirements.txt
    if req_txt.exists():
        _mark(req_txt, "requirements.txt", True)
        for r in parse_requirements_txt(req_txt.read_text(errors="replace")):
            entries.append({"requirement": r, "source": "requirements.txt"})
    else:
        _mark(req_txt, "requirements.txt", False)

    # 5) PKG-INFO backstop - generated at build time; for Metadata-Version
    #    >= 2.1 it lists Requires-Dist regardless of build backend.
        
    if pkg_info.exists():
        if not entries:
            for line in pkg_info.read_text(errors="replace").splitlines():
                if line.startswith("Requires-Dist:"):
                    entries.append({"requirement": line.split(":", 1)[1].strip(),
                                    "source": "PKG-INFO (backstop)"})
            found.append("PKG-INFO")

    return {"dependencies": entries, "files_found": found, "files_missing": missing}


# ---------------------------------------------------------------------------
# Metadata extraction (for "Further Analysis" / Maliciousness Triage)
# ---------------------------------------------------------------------------

def _parse_iso(ts: str):
    if not ts:
        return None
    ts = ts.replace("Z", "+00:00")
    for candidate in (ts, ts[:19]):
        try:
            dt = datetime.fromisoformat(candidate)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt
        except ValueError:
            continue
    return None


def _license_from_classifiers(classifiers: list) -> str:
    for c in classifiers or []:
        if c.startswith("License ::"):
            return c.split("::")[-1].strip()
    return ""


def _find_source_repo(project_urls: dict) -> str:
    """Try to identify a source-code repository URL."""
    if not project_urls:
        return ""
    for key, url in project_urls.items():
        if not url:
            continue
        low_key, low_url = key.lower(), url.lower()
        if any(k in low_key for k in ("source", "repository", "code", "github", "git")):
            return url
        if any(h in low_url for h in ("github.com", "gitlab.com", "bitbucket.org")):
            return url
    return ""


def extract_useful_metadata(meta: dict) -> dict:
    """Pull the fields most useful for deciding whether a package is worth a closer look."""
    info = meta.get("info", {})
    releases = meta.get("releases", {})
    version = info.get("version", "")

    # gather every upload time across every release to bound the package's age
    all_times = []
    for _ver, files in releases.items():
        for f in files:
            dt = _parse_iso(f.get("upload_time_iso_8601") or f.get("upload_time"))
            if dt:
                all_times.append(dt)
    all_times.sort()

    latest_files = releases.get(version) or meta.get("urls", [])
    latest_times = sorted(
        dt for f in latest_files
        if (dt := _parse_iso(f.get("upload_time_iso_8601") or f.get("upload_time")))
    )

    first_release = all_times[0] if all_times else None
    latest_release = latest_times[0] if latest_times else (all_times[-1] if all_times else None)
    now = datetime.now(timezone.utc)

    project_urls = info.get("project_urls") or {}
    repo = _find_source_repo(project_urls)
    license_str = info.get("license") or _license_from_classifiers(info.get("classifiers"))

    return {
        "summary": info.get("summary") or "",
        "author": info.get("author") or "",
        "author_email": info.get("author_email") or "",
        "maintainer": info.get("maintainer") or "",
        "maintainer_email": info.get("maintainer_email") or "",
        "license": (license_str or "").strip()[:120],
        "requires_python": info.get("requires_python") or "",
        "keywords": info.get("keywords") or "",
        "home_page": info.get("home_page") or "",
        "project_urls": project_urls,
        "source_repository": repo,
        "has_source_repository": bool(repo),
        "has_description": bool(info.get("description")),
        "yanked": bool(info.get("yanked", False)),
        "yanked_reason": info.get("yanked_reason") or "",
        "total_versions": len(releases),
        "first_release": first_release.date().isoformat() if first_release else "",
        "latest_release": latest_release.date().isoformat() if latest_release else "",
        "package_age_days": (now - first_release).days if first_release else None,
        "days_since_latest_release": (now - latest_release).days if latest_release else None,
        "dev_status": [c for c in info.get("classifiers", []) if c.startswith("Development Status")],
    }


def _has_human_name(md: dict) -> bool:
    """True if we can find an author/maintainer *name* anywhere."""
    # explicit name fields
    if (md.get("author") or "").strip() or (md.get("maintainer") or "").strip():
        return True
    # name embedded in an email field: text outside the <...>, or before the '@'
    for field_val in (md.get("author_email"), md.get("maintainer_email")):
        if not field_val:
            continue
        # 'Real Name <addr@x>' -> capture 'Real Name'
        display = re.sub(r"<[^>]*>", "", field_val).strip().strip(",").strip()
        if display:
            return True
    return False


def compute_risk_signals(md: dict) -> list:
    """Cheap heuristic flags. These are NOT a For a supply-chain review, 'new + no repo + no license' 
    is a classic typosquat/dependency-confusion shape."""
    signals = []
    age = md.get("package_age_days")
    if age is not None and age < 30:
        signals.append(
            f"Package first published only {age} day(s) ago - verify it isn't a "
            "typosquat or a newly-published malicious package."
        )
    if md.get("total_versions", 0) <= 1:
        signals.append("Only a single release version exists on PyPI.")
    if not md.get("has_source_repository"):
        signals.append("No source-code repository URL is declared - can't easily "
                       "audit the real source.")
    if not md.get("license"):
        signals.append("No license is declared.")
    if md.get("yanked"):
        signals.append(f"This release is YANKED from PyPI"
                       + (f" (reason: {md['yanked_reason']})." if md.get("yanked_reason") else "."))
    if not md.get("has_description"):
        signals.append("Package has no long description / README.")
    if not _has_human_name(md):
        signals.append("No author or maintainer is declared (neither a name nor "
                       "a contact email).")
    return signals


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------

def run(package_name: str, fmt: str, out_dir: Path, do_download: bool) -> PackageReport:
    package_name = validate_package_name(package_name)
    report = PackageReport(name=package_name, requested_format=fmt)

    metadata = get_package_metadata(package_name)
    version = metadata["info"]["version"]
    report.resolved_version = version
    print(f"[+] Latest version of '{package_name}' is {version}")

    # pull descriptive metadata + heuristic signals up front - useful even with --no-download
    report.metadata = extract_useful_metadata(metadata)
    report.risk_signals = compute_risk_signals(report.metadata)

    releases_for_version = metadata.get("releases", {}).get(version, [])
    if not releases_for_version:
        # fall back to the top-level "urls" key, which PyPI populates for the current release
        releases_for_version = metadata.get("urls", [])

    if not do_download:
        report.warnings.append("--no-download set: skipping download and dependency extraction.")
        return report

    if not releases_for_version:
        raise ScraperError("PyPI reports a version but no downloadable files for it.")

    chosen_files = pick_release_files(releases_for_version, fmt)
    out_dir.mkdir(parents=True, exist_ok=True)

    all_deps = set()
    for file_info in chosen_files:
        art = Artifact(
            filename=file_info["filename"],
            url=file_info["url"],
            packagetype=file_info.get("packagetype", "unknown"),
            sha256_expected=file_info.get("digests", {}).get("sha256", ""),
        )
        print(f"[+] Downloading {file_info['filename']} "
              f"({file_info.get('size', '?')} bytes)")
        artifact_path, actual_hash, expected_hash = download_artifact(file_info, out_dir)
        art.sha256_actual = actual_hash
        art.integrity_verified = (actual_hash == expected_hash)
        print(f"[+] SHA-256 verified OK: {actual_hash}")

        print("[+] Extracting dependency metadata "
              "(static parsing only, no code execution)")
        if artifact_path.suffix == ".whl":
            result = parse_wheel_metadata(artifact_path)
        else:  # .tar.gz / .tgz / .zip sdist
            result = extract_sdist_dependencies(artifact_path, out_dir)

        art.dependencies = result["dependencies"]
        art.files_found = result["files_found"]
        art.files_missing = result["files_missing"]

        if art.packagetype == "sdist" and "setup.py" in art.files_missing:
            report.warnings.append(
                f"{art.filename}: no setup.py present. This is normal for modern "
                "pyproject.toml-based packages; dependencies were taken from: "
                + (", ".join(art.files_found) or "no parseable source (see below)") + "."
            )

        if not art.dependencies and _toml is None and art.packagetype == "sdist":
            report.warnings.append(
                f"{art.filename}: no deps resolved and no TOML parser is "
                "installed - a pyproject.toml-only package may be under-"
                "reported. Install 'tomli' or use --format wheel/both."
            )

        for entry in art.dependencies:
            all_deps.add((entry["requirement"], entry["source"]))
        report.artifacts.append(art)

    report.dependencies = [
        {"requirement": r, "source": s}
        for (r, s) in sorted(all_deps)
    ]
    return report


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Fetch, download, and extract dependencies for a PyPI package."
    )
    p.add_argument("package", help="Name of the package on PyPI, e.g. 'requests'")
    p.add_argument(
        "--format", choices=["wheel", "sdist", "both"], default="both",
        help="Which artifact type(s) to download (default: both). 'both' pulls "
             "the wheel AND the .tar.gz sdist so dependency sources can be "
             "cross-checked; 'wheel' or 'sdist' fetch just that one."
    )
    p.add_argument(
        "--out", default="./pypi_downloads",
        help="Directory to download and extract into (default: ./pypi_downloads)"
    )
    p.add_argument(
        "--json", metavar="FILE",
        help="Write the structured report as JSON to this file"
    )
    p.add_argument(
        "--no-download", action="store_true",
        help="Only resolve the latest version, skip download/extraction"
    )
    return p


def _print_metadata(md: dict):
    print("\n=== Package Metadata Analysis ===")
    fields = [
        ("Summary", md.get("summary")),
        ("Author", md.get("author")),
        ("Author email", md.get("author_email")),
        ("Maintainer", md.get("maintainer")),
        ("Maintainer email", md.get("maintainer_email")),
        ("License", md.get("license")),
        ("Requires-Python", md.get("requires_python")),
        ("Keywords", md.get("keywords")),
        ("Home page", md.get("home_page")),
        ("Source repository", md.get("source_repository")),
    ]
    for label, val in fields:
        if val:
            print(f"  {label:<18}: {val}")
    if md.get("dev_status"):
        print(f"  {'Development status':<18}: {', '.join(md['dev_status'])}")
    print(f"  {'Total versions':<18}: {md.get('total_versions')}")
    if md.get("first_release"):
        age = md.get("package_age_days")
        print(f"  {'First published':<18}: {md['first_release']}"
              + (f"  ({age} days ago)" if age is not None else ""))
    if md.get("latest_release"):
        d = md.get("days_since_latest_release")
        print(f"  {'Latest release':<18}: {md['latest_release']}"
              + (f"  ({d} days ago)" if d is not None else ""))
    print(f"  {'Yanked':<18}: {md.get('yanked')}"
          + (f" ({md.get('yanked_reason')})" if md.get("yanked_reason") else ""))
    # any extra project URLs worth eyeballing
    extra_urls = {k: v for k, v in (md.get("project_urls") or {}).items()}
    if extra_urls:
        print(f"  {'Project URLs':<18}:")
        for k, v in extra_urls.items():
            print(f"      - {k}: {v}")


def _print_dependencies(report: PackageReport):
    if not report.dependencies:
        print("\n=== Dependencies ===")
        print("  none declared, or none could be statically resolved.")
        return
    # group by source file so it's clear where each came from
    by_source = {}
    for entry in report.dependencies:
        by_source.setdefault(entry["source"], []).append(entry["requirement"])
    total = len(report.dependencies)
    print(f"\n=== Dependencies ({total} total, grouped by source file) ===")
    for source in sorted(by_source):
        reqs = sorted(by_source[source])
        print(f"  From {source} ({len(reqs)}):")
        for r in reqs:
            print(f"    - {r}")


def _print_file_audit(report: PackageReport):
    print("\n=== Source files scanned ===")
    for a in report.artifacts:
        print(f"  {a.filename}:")
        print(f"    found:   {', '.join(a.files_found) or '(none)'}")
        if a.packagetype == "sdist":
            print(f"    missing: {', '.join(a.files_missing) or '(none)'}")


def main():
    args = build_arg_parser().parse_args()

    try:
        report = run(
            package_name=args.package,
            fmt=args.format,
            out_dir=Path(args.out),
            do_download=not args.no_download,
        )
    except ScraperError as e:
        print(f"[!] {e}", file=sys.stderr)
        sys.exit(1)

    print("\n" + "=" * 60)
    print(f"REPORT: {report.name} {report.resolved_version}")
    print("=" * 60)

    _print_metadata(report.metadata)

    print("\n=== Supply-Chain Risk Indicators ===")
    if report.risk_signals:
        for s in report.risk_signals:
            print(f"  [!] {s}")
    else:
        print("  none flagged by the basic heuristics.")

    if report.artifacts:
        print("\n=== Artifacts downloaded ===")
        for a in report.artifacts:
            status = "verified" if a.integrity_verified else "NOT VERIFIED"
            print(f"  - {a.filename}  [{a.packagetype}, integrity: {status}]")

    _print_dependencies(report)

    if report.artifacts:
        _print_file_audit(report)

    if report.warnings:
        print("\n=== Notes / warnings ===")
        for w in report.warnings:
            print(f"  [note] {w}")

    if args.json:
        with open(args.json, "w") as f:
            json.dump(report.to_dict(), f, indent=2)
        print(f"\n[+] Full structured report written to {args.json}")


if __name__ == "__main__":
    main()
